//
// Created by duarte on 13-11-2022.
//

#ifndef POO_NATURAL_RESERVE_ENTITY_H
#define POO_NATURAL_RESERVE_ENTITY_H

class Entity {
public:
    static int id;
    static int defineNewId();
};


#endif //POO_NATURAL_RESERVE_ENTITY_H
