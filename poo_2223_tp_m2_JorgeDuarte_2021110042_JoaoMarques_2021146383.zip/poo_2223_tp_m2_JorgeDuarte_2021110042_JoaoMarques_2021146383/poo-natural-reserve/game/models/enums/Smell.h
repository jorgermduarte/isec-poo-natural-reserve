//
// Created by duarte on 10-11-2022.
//

#ifndef POO_NATURAL_RESERVE_SMELL_H
#define POO_NATURAL_RESERVE_SMELL_H


enum Smell {
    ENUM_Grass,
    ENUM_Vegetables,
    ENUM_Meat,
    ENUM_Ketchup,
};


#endif //POO_NATURAL_RESERVE_SMELL_H
