//
// Created by duarte on 11-11-2022.
//

#ifndef POO_NATURAL_RESERVE_MATRIXSIZE_H
#define POO_NATURAL_RESERVE_MATRIXSIZE_H


class MatrixSize {
public:
    int cols;
    int rows;
    MatrixSize(int h, int w);
};


#endif //POO_NATURAL_RESERVE_MATRIXSIZE_H
