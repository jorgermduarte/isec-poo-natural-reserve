//
// Created by duarte on 11-11-2022.
//

#include "MatrixSize.h"


MatrixSize::MatrixSize(int h, int w) {
    this->rows = h;
    this->cols = w;
}