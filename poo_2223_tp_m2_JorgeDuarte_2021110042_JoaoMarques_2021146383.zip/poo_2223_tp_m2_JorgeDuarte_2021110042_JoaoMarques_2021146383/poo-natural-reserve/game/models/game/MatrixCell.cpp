//
// Created by duarte on 11-11-2022.
//

#include "MatrixCell.h"


MatrixCell::MatrixCell(int col, int line) {
    this->position = Position(col,line);
}