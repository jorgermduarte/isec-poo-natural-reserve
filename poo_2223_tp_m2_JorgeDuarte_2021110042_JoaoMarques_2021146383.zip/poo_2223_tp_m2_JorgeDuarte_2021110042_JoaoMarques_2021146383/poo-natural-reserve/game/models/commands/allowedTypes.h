﻿#include <string>
#include <vector>

const static std::vector<std::string> allowedAnimalsTypes = { "c", "o", "l","g","m"};
const static std::vector<std::string> allowedFoodTypes = { "r", "t", "b", "a"};

