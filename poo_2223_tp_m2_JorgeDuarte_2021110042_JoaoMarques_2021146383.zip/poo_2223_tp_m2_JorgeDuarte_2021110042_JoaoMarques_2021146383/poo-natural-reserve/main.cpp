#include "game/services/GameService.h"

int main() {
    GameService gameService = GameService();
    gameService.initialize();

    return 0;
}
